java -jar BrickGame.jar
